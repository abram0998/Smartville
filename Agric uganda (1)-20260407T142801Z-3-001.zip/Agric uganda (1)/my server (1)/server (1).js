//Import Express.js
const express = require('express')
//Create an app using Express
const app= express();
//Set a port number 
const port= 3000
//Create a simple API route :When someone visits "/", send"Hello from Backend!"
app.get('/',( req,res)=> {
    res.send('Hello from the backend! This is our first API response.');
});

//Start the server and listen on the port
app.listen(port,()=>{
    console.log('Server is running at http://localhost:${3000}')
});

 